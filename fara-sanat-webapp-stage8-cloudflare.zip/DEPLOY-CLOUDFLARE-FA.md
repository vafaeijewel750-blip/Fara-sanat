# راه‌اندازی فارا صنعت روی Cloudflare Pages

این نسخه برای **Cloudflare Pages + GitHub** آماده شده است. Vercel لازم نیست.

## چرا این روش؟
- آدرس اصلی پروژه روی `pages.dev` ثابت می‌ماند.
- با هر Push به GitHub، Cloudflare خودکار نسخه جدید را منتشر می‌کند.
- فایل Excel و تصاویر در GitHub نگهداری می‌شوند.
- GitHub Actions بعد از تغییر Excel/تصاویر، اطلاعات جستجو را خودکار بازسازی می‌کند.

## مرحله 1 — ساخت Repository در GitHub
1. وارد GitHub شوید.
2. روی **New repository** بزنید.
3. نام پیشنهادی: `fara-sanat`
4. Repository را **Public** انتخاب کنید.
5. Repository را بسازید.
6. تمام محتویات این پوشه را در ریشه Repository قرار دهید؛ یعنی `index.html` باید مستقیماً در ریشه باشد، نه داخل یک پوشه دیگر.

## مرحله 2 — اتصال به Cloudflare Pages
1. وارد Cloudflare شوید.
2. بخش **Workers & Pages** را باز کنید.
3. **Create application** را بزنید.
4. تب **Pages** را انتخاب کنید.
5. **Import an existing Git repository** را انتخاب کنید.
6. GitHub را وصل کنید و Repository `fara-sanat` را انتخاب کنید.
7. تنظیمات زیر را وارد کنید:

- Production branch: `main`
- Framework preset: بدون Framework / None
- Build command: `exit 0`
- Build output directory: `.`
- Root directory: خالی / ریشه Repository

سپس **Save and Deploy** را بزنید.

## مرحله 3 — آدرس نهایی
Cloudflare یک آدرس شبیه این می‌دهد:

`https://fara-sanat.pages.dev`

این آدرس را نگه می‌داریم و برای مشتری‌ها استفاده می‌کنیم.

## آپدیت هفتگی
هر هفته فقط:

1. فایل Excel جدید را با نام دقیق `data-source/price-list.xlsx` جایگزین کنید.
2. تصاویر جدید را داخل پوشه `images` جایگزین/اضافه کنید.
3. تغییرات را در GitHub Commit کنید.
4. GitHub Actions به‌صورت خودکار `data.json`، `data-inline.js`، `image-map.json` و گزارش تصاویر را بازسازی می‌کند.
5. Cloudflare Pages بعد از Push، نسخه جدید را خودکار منتشر می‌کند.

### نکته مهم
برای تغییرات هفتگی، لازم نیست `data.json` یا `data-inline.js` را دستی ویرایش کنید.

## تست اصلی قبل از انتشار
بعد از انتشار، این موارد را تست کنید:

- جستجوی `لیفان X50`
- نمایش کد جلو `1184`
- لمس کد `1184` و نمایش خودروهای مشترک جلو
- جستجوی مستقیم `1184`
- نمایش تصویر لنت در صورت وجود تصویر
- باز شدن سایت روی موبایل

در فایل فعلی، کد `1184` در بخش جلو برای 5 خودرو وجود دارد و برای تست بسیار مناسب است.
