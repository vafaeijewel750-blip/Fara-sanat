import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'data.json').read_text(encoding='utf-8'))
records = data.get('records', [])
errors = []
warnings = []

if not records:
    errors.append('No product records were generated.')

def norm(s):
    return re.sub(r'\s+', '', str(s or '').strip().lower().replace('ي','ی').replace('ى','ی').replace('ك','ک').replace('\u200c',''))

seen = {}
for i, r in enumerate(records, 1):
    if not (r.get('name') or r.get('front_code') or r.get('rear_code')):
        errors.append(f'Row {i}: empty product record.')
    for field in ('front_code', 'rear_code'):
        code = str(r.get(field) or '').strip()
        if code:
            key = norm(code)
            seen.setdefault(key, []).append((i, field, code))

for key, items in seen.items():
    # Same code may legitimately be shared by multiple vehicle models.
    if len(items) > 1:
        models = ', '.join(f'#{i} {c}' for i, _, c in items[:4])
        warnings.append(f'Shared code {key}: {models}')

image_map = json.loads((ROOT / 'image-map.json').read_text(encoding='utf-8'))
for key, path in image_map.items():
    if not (ROOT / path.lstrip('./')).is_file():
        errors.append(f'Image mapping points to missing file: {path}')

print(f'VALIDATION: {len(records)} records, {len(image_map)} image mappings')
for w in warnings[:20]: print('WARNING:', w)
if len(warnings) > 20: print(f'WARNING: ... {len(warnings)-20} more shared-code notices')
for e in errors: print('ERROR:', e)
if errors:
    raise SystemExit(1)
print('Validation passed.')
