import json, re
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
EXCEL=ROOT/"data-source"/"price-list.xlsx"
OUT=ROOT/"data.json"
INLINE_OUT=ROOT/"data-inline.js"
IMG_DIR=ROOT/"images"
IMG_OUT=ROOT/"image-map.json"
REPORT_OUT=ROOT/"image-report.json"

def clean(v):
    if pd.isna(v): return ""
    s=str(v).strip()
    if re.fullmatch(r"\d+\.0",s): s=s[:-2]
    return s

def norm(s):
    return re.sub(r"\s+","",str(s).strip().lower().replace("ي","ی").replace("ى","ی").replace("ك","ک").replace("\u200c",""))

df=pd.read_excel(EXCEL,sheet_name="اصلی",header=None)
records=[]
for _,row in df.iloc[9:].iterrows():
    name=clean(row[12]); front_code=clean(row[10]); front_price=clean(row[7]); rear_code=clean(row[5]); rear_price=clean(row[2])
    front_note=clean(row[9]); rear_note=clean(row[4])
    if not front_code and not rear_code: continue
    records.append({"name":name,"front_code":front_code,"front_price":front_price,"rear_code":rear_code,"rear_price":rear_price,"front_note":front_note,"rear_note":rear_note})

payload={"source_file":EXCEL.name,"sheet":"اصلی","records":records}
with open(OUT,"w",encoding="utf-8") as f:
    json.dump(payload,f,ensure_ascii=False,indent=2)

codes={c for r in records for c in (r["front_code"],r["rear_code"]) if c}
image_map={}
files=[]
if IMG_DIR.exists():
    for p in IMG_DIR.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".jpg",".jpeg",".png",".webp"}:
            files.append(p)
by_norm={norm(p.stem):p for p in files}
for code in sorted(codes):
    p=by_norm.get(norm(code))
    if p:
        image_map[norm(code)]="./"+p.relative_to(ROOT).as_posix()
# Supplied filename convention: 1673.1.jpg represents code 167301.
if "167301" in codes and norm("167301") not in image_map:
    p=by_norm.get(norm("1673.1"))
    if p: image_map[norm("167301")]= "./"+p.relative_to(ROOT).as_posix()

with open(IMG_OUT,"w",encoding="utf-8") as f: json.dump(image_map,f,ensure_ascii=False,indent=2)
# Self-contained browser data: avoids fetch/CORS/loading problems when opening locally.
with open(INLINE_OUT,"w",encoding="utf-8") as f:
    f.write("window.FARA_DATA="+json.dumps(payload,ensure_ascii=False,separators=(",",":"))+";\n")
    f.write("window.FARA_IMAGE_MAP="+json.dumps(image_map,ensure_ascii=False,separators=(",",":"))+";\n")

matched=set(image_map)
report={"excel_rows":len(records),"unique_codes":len(codes),"image_files":len(files),"matched_codes":len(matched),
        "missing_codes":sorted(codes-matched),"unmatched_image_files":sorted([p.name for p in files if norm(p.stem) not in codes and p.stem!="1673.1"])}
with open(REPORT_OUT,"w",encoding="utf-8") as f: json.dump(report,f,ensure_ascii=False,indent=2)
print(f"Generated {len(records)} product rows, {len(codes)} unique codes, {len(image_map)} image mappings")
