let DB=[], IMAGE_MAP={};
const $=id=>document.getElementById(id); let installPrompt=null;
const RECENT_KEY="fara_recent_searches_v4";

function normalize(s){return String(s??"").replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/[يى]/g,"ی").replace(/[ك]/g,"ک").replace(/[ۀة]/g,"ه").replace(/ـ/g,"").replace(/[\u200c\u200b]/g," ").replace(/\s+/g," ").trim().toLowerCase()}
function compact(s){return normalize(s).replace(/\s+/g,"")}
function displayNumber(n){const s=String(n??"").trim();if(!s)return "";const x=s.replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/[,،\s]/g,"");if(/^\d+(\.\d+)?$/.test(x)){const num=Number(x);return Number.isInteger(num)?num.toLocaleString("fa-IR"):num.toLocaleString("fa-IR",{maximumFractionDigits:2})}return s}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function imageFor(code){const k=compact(code);return IMAGE_MAP[k]||IMAGE_MAP[normalize(code)]||""}

function codeSearch(code,side=""){
 const k=compact(code);
 return DB.filter(r=>side==="front"?compact(r.front_code)===k:side==="rear"?compact(r.rear_code)===k:compact(r.front_code)===k||compact(r.rear_code)===k);
}
function codeCount(code,side=""){return codeSearch(code,side).length}
function uniqueImages(list,onlyCode=""){
 const seen=new Set(),out=[];
 if(onlyCode){const src=imageFor(onlyCode);if(src)out.push({code:onlyCode,src});return out}
 for(const r of list)for(const code of [r.front_code,r.rear_code]){const src=imageFor(code),k=compact(code);if(src&&!seen.has(k)){seen.add(k);out.push({code,src})}}
 return out.slice(0,6)
}
function renderImageStrip(list,onlyCode=""){
 const box=$("imageStrip"),imgs=uniqueImages(list,onlyCode);
 if(!imgs.length){box.innerHTML="";box.classList.remove("show");return}
 box.classList.add("show");
 box.innerHTML=imgs.map(x=>`<div class="imageCard"><img loading="lazy" src="${esc(x.src)}" alt="لنت کد ${esc(x.code)}" onerror="this.closest('.imageCard').remove()"><span>${esc(x.code)}</span></div>`).join("");
}
function sharedButton(code,side){const count=codeCount(code,side);if(count<=1)return "";const label=side==="front"?"جلو":"عقب";return `<button class="shared" data-shared-code="${esc(code)}" data-shared-side="${side}">خودروهای مشترک ${label}: ${count.toLocaleString("fa-IR")} ←</button>`}
function itemHtml(code,price,side){if(!code)return "";return `<div class="item"><div class="sideTitle">لنت ${side==="front"?"جلو":"عقب"}</div><div class="codeLine"><button class="codeLink" data-shared-code="${esc(code)}" data-shared-side="${side}" title="نمایش خودروهای مشترک">${esc(code)}</button><button class="copy" data-copy="${esc(code)}">کپی</button></div><div class="price">${esc(displayNumber(price))} <span class="priceUnit">تومان</span></div>${sharedButton(code,side)}</div>`}
function render(list,q,mode="normal",onlyCode="",onlySide=""){
 renderImageStrip(list,onlyCode);const box=$("results");
 if(!q){box.innerHTML='<div class="start"><strong>برای شروع جستجو کنید</strong>مثلاً «لیفان X50» یا کد فنی «1184»</div>';return}
 if(!list.length){box.innerHTML='<div class="card empty"><strong>نتیجه‌ای پیدا نشد</strong>نام خودرو یا کد را کمی کوتاه‌تر یا با بخشی از کد وارد کنید.</div>';return}
 box.innerHTML=list.map(r=>{if(mode==="shared"){const isFront=onlySide==="front";return `<article class="card sharedCard"><div class="name">${esc(r.name||"بدون نام خودرو")}</div><div class="sharedRow"><span class="sideBadge">${isFront?"جلو":"عقب"}</span><strong class="sharedCode">${esc(onlyCode)}</strong><span class="priceSmall">${esc(displayNumber(isFront?r.front_price:r.rear_price))} تومان</span><button class="copy" data-copy="${esc(onlyCode)}">کپی</button></div></article>`}return `<article class="card"><div class="name">${esc(r.name||"بدون نام خودرو")}</div><div class="grid">${itemHtml(r.front_code,r.front_price,"front")}${itemHtml(r.rear_code,r.rear_price,"rear")}</div></article>`}).join("")
}
function searchScore(r,q){const nq=normalize(q),cq=compact(q);let score=0;for(const raw of [r.name,r.front_code,r.rear_code]){const f=normalize(raw),c=compact(raw);if(!f)continue;if(c===cq)score=Math.max(score,1200);else if(c.startsWith(cq))score=Math.max(score,900);else if(c.includes(cq))score=Math.max(score,550);else if(f.includes(nq))score=Math.max(score,350)}return score}
function doSharedSearch(code,side,save=true){const q=normalize(code),out=codeSearch(q,side);$("q").value=code;$("clear").style.display="block";$("resultTitle").textContent=`خودروهای مشترک کد ${q}`;$("resultHint").textContent=`لنت ${side==="front"?"جلو":"عقب"} • ${out.length.toLocaleString("fa-IR")} خودرو`;render(out,q,"shared",code,side);renderSuggestions("",[],true);if(save&&out.length)addRecent(code.trim());window.scrollTo({top:0,behavior:"smooth"})}
function doSearch(raw,save=true){const q=normalize(raw);$("clear").style.display=q?"block":"none";if(!q){render([]);$("resultTitle").textContent="محصولات";$("resultHint").textContent="";renderRecent();return}const exact=codeSearch(q);let out,onlyCode="";if(exact.length){out=exact;$("resultTitle").textContent=`خودروهای دارای کد ${q}`;$("resultHint").textContent=`${out.length.toLocaleString("fa-IR")} خودرو • جلو یا عقب`;onlyCode=q}else{out=DB.map((r,i)=>({r,s:searchScore(r,q),i})).filter(x=>x.s>0).sort((a,b)=>b.s-a.s||a.i-b.i).slice(0,100).map(x=>x.r);$("resultTitle").textContent="نتایج جستجو";$("resultHint").textContent=`${out.length.toLocaleString("fa-IR")}${out.length===100?"+":""} مورد`}render(out,q,"normal",onlyCode);renderSuggestions(q,out,!!exact.length);if(save&&out.length)addRecent(raw.trim())}
function renderSuggestions(q,list,isCode){const box=$("suggestions");if(!q||!list.length||isCode){box.classList.remove("show");box.innerHTML="";return}const names=[],seen=new Set();for(const r of list){const n=String(r.name||"").trim(),k=normalize(n);if(n&&!seen.has(k)){seen.add(k);names.push(n)}if(names.length>=5)break}if(!names.length){box.classList.remove("show");return}box.innerHTML=names.map(n=>`<button class="suggest" data-suggest="${esc(n)}">خودرو: <b>${esc(n)}</b></button>`).join("");box.classList.add("show")}
function getRecent(){try{return JSON.parse(localStorage.getItem(RECENT_KEY)||"[]").filter(Boolean).slice(0,6)}catch{return []}}
function addRecent(q){const a=[q,...getRecent().filter(x=>normalize(x)!==normalize(q))].slice(0,6);try{localStorage.setItem(RECENT_KEY,JSON.stringify(a))}catch{}renderRecent()}
function renderRecent(){const box=$("recent"),a=getRecent();if(!a.length){box.classList.remove("show");box.innerHTML="";$("recentLabel").style.display="none";return}$("recentLabel").style.display="block";box.classList.add("show");box.innerHTML=a.map(x=>`<button data-recent="${esc(x)}">${esc(x)}</button>`).join("")}
function renderQuick(){const box=$("quick"),names=[],seen=new Set();for(const r of DB){const n=String(r.name||"").trim(),k=normalize(n);if(n&&!seen.has(k)){seen.add(k);names.push(n)}if(names.length>=6)break}box.innerHTML=names.map(n=>`<button data-quick="${esc(n)}">${esc(n)}</button>`).join("")}
function setLoaded(data,map){DB=Array.isArray(data?.records)?data.records:[];IMAGE_MAP=map&&typeof map==="object"?map:{};if(!DB.length)throw new Error("داده‌ای در پایگاه اطلاعاتی وجود ندارد");$("status").textContent="آماده جستجو";$("count").textContent=`${DB.length.toLocaleString("fa-IR")} مدل`;renderRecent();renderQuick()}
async function load(){
 // Self-contained data is used first. This prevents the app from getting stuck on "در حال بارگذاری" when opened locally or when a static host has a fetch/cache issue.
 if(window.FARA_DATA){setLoaded(window.FARA_DATA,window.FARA_IMAGE_MAP||{});return}
 const timeout=new Promise((_,rej)=>setTimeout(()=>rej(new Error("timeout")),8000));
 const request=Promise.all([fetch("data.json?v=6",{cache:"no-store"}).then(r=>{if(!r.ok)throw new Error("data.json "+r.status);return r.json()}),fetch("image-map.json?v=6",{cache:"no-store"}).then(r=>r.ok?r.json():{})]);
 const [data,map]=await Promise.race([request,timeout]);setLoaded(data,map)
}
$("q").addEventListener("input",e=>{const q=e.target.value;if(normalize(q).length>=1)doSearch(q,false);else doSearch("")});
$("q").addEventListener("keydown",e=>{if(e.key==="Enter"){const first=document.querySelector(".suggest");if(first)first.click();else if(e.target.value.trim())addRecent(e.target.value.trim())}});
$("clear").onclick=()=>{$("q").value="";doSearch("");$("q").focus()};
$("quick").addEventListener("click",e=>{const b=e.target.closest("[data-quick]");if(b){$("q").value=b.dataset.quick;doSearch(b.dataset.quick)}});
$("recent").addEventListener("click",e=>{const b=e.target.closest("[data-recent]");if(b){$("q").value=b.dataset.recent;doSearch(b.dataset.recent,false)}});
$("suggestions").addEventListener("click",e=>{const b=e.target.closest("[data-suggest]");if(b){$("q").value=b.dataset.suggest;doSearch(b.dataset.suggest);$("suggestions").classList.remove("show")}});
$("results").addEventListener("click",async e=>{const shared=e.target.closest("[data-shared-code]");if(shared&&!e.target.closest(".copy")){doSharedSearch(shared.dataset.sharedCode,shared.dataset.sharedSide);return}const b=e.target.closest(".copy");if(!b)return;try{await navigator.clipboard.writeText(b.dataset.copy);b.classList.add("ok");b.textContent="کپی شد ✓";setTimeout(()=>{b.classList.remove("ok");b.textContent="کپی"},1200)}catch{}});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("installBtn").style.display="block"});
$("installBtn").onclick=async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("installBtn").style.display="none"};
window.addEventListener("appinstalled",()=>$("installBtn").style.display="none");
if("serviceWorker" in navigator&&location.protocol!=="file:")window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js?v=6").catch(()=>{}));
load().catch(e=>{$("status").textContent="خطا در بارگذاری اطلاعات";$("count").textContent="";$('results').innerHTML='<div class="card empty"><strong>اطلاعات بارگذاری نشد</strong>فایل داده در دسترس نیست. اتصال یا فایل‌های برنامه را بررسی کنید.</div>';console.error(e)});
